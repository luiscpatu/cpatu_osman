#if defined(_WIN32) && (WINAPI_FAMILY==WINAPI_FAMILY_PHONE_APP)

#ifndef _OSMAND_WP_UNISTD_H
#define _OSMAND_WP_UNISTD_H

// Simply empty file

#endif // _OSMAND_WP_UNISTD_H

#endif // defined(_WIN32) && (WINAPI_FAMILY==WINAPI_FAMILY_PHONE_APP)