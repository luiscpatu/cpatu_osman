package net.osmand.plus.download;

public enum DownloadActivityType {
	NORMAL_FILE, ROADS_FILE, SRTM_FILE
}