OsmAnd-misc
===========